#ifndef ALIASES_H
#define ALIASES_H

#include <vector>

using NewPoint = std::vector<double>;
using Trace = std::vector<NewPoint>;

#endif /* ALIASES_H */
